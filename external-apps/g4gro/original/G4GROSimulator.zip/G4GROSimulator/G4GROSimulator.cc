/*

	A Meiga application for simulating Water-Cherenkov Detectors

	author: alvaro taboada
	date: 9 Feb 2022

 */

// Headers of this particular application
#include "G4GROSimulator.h"
#include "G4GROConstruction.h"
#include "G4MPrimaryGeneratorAction.h"
#include "G4GROStackingAction.h"
#include "G4GROEventAction.h"
#include "G4GRORunAction.h"
#include "G4GROTrackingAction.h"
#include "G4GROSteppingAction.h"

// Geant4 headers
#include "G4RunManagerFactory.hh"
#include "G4UImanager.hh"
#include "G4VisExecutive.hh"
#include "G4UIExecutive.hh"
#include "Randomize.hh"

// Framework libraries
#include "ConfigManager.h"
#include "CorsikaUtilities.h"
#include "Event.h"
#include "SimData.h"
#include "OptDeviceSimData.h"
#include "Detector.h"
#include "OptDevice.h"
#include "G4MPhysicsList.h"
#include "DataWriter.h"

#include <iostream>
#include <fstream>
#include <ctime>
#include <chrono>


using namespace std;

Particle G4GROSimulator::currentParticle;
G4GROSimulator* fG4GROSimulator;
string fCfgFile;

G4GROSimulator::G4GROSimulator()
{

}

namespace
{
	void ProgramUsage()
	{
		cerr << " Program Usage: " << endl;
		cerr << " ./G4GROSimulator [ -c ConfigFile.json ] " << endl;
	}

}


int main(int argc, char** argv)
{

	if (argc < 3) {
		ProgramUsage();
		throw invalid_argument("[ERROR] G4GROSimulator::main: A configuration file is needed!");
	}

	for (int i=1; i<argc; i=i+2) {
		string sarg(argv[i]);
		if (sarg == "-c")
			fCfgFile = argv[i+1];
	}

	// for program time calculation
	time_t start, end;
	time(&start);

	fG4GROSimulator = new G4GROSimulator();
	// Create Event object
	Event theEvent;
	fG4GROSimulator->Initialize(theEvent, fCfgFile);
	fG4GROSimulator->RunSimulation(theEvent);
	/*************************************************

		Geant4 simulation ended here!
		What happens nATMt is up to you =)

	**************************************************/
	fG4GROSimulator->WriteEventInfo(theEvent);
	time(&end);

	// Calculating total time taken by the program.
	double time_taken = double(end - start);
	cout << "[INFO] G4GROSimulator: Time taken by program is : " << fixed
			 << time_taken << setprecision(5);
	cout << " sec " << endl;

/*
      // Obtener la fecha y hora actual
    	time_t rawtime;
    	struct tm* timeinfo;
    	char timestamp[80];
    	time(&rawtime);
    	timeinfo = localtime(&rawtime);
    	strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", timeinfo);

    	// Obtener el nombre de la máquina
    	char hostname[256];
    	gethostname(hostname, sizeof(hostname));

    	// Obtener el número de hilos utilizados por Geant4
    	int numThreads = G4Threading::G4GetNumberOfCores();

    	// Obtener el número de cores de la máquina
    	int numCores = std::thread::hardware_concurrency();
			// Configuration
	    Event::Config &cfg = fEvent.GetConfig();
	    std::string& outputFileName = cfg.fOutputFileName;
			std::ofstream outfile_Neutrons_before_ground(outputFileName + "_info_simulation", std::ios_base::app);
    	// Guardar la información en un archivo
    	infoFile << "Fecha y hora de ejecución: " << timestamp << endl;
    	infoFile << "Nombre de la máquina: " << hostname << endl;
    	infoFile << "Tiempo de simulación (segundos): " << time_taken << endl;
    	infoFile << "-----------------------------------------" << endl;
    	infoFile << "Número de hilos utilizados por Geant4: " << numThreads << endl;
    	infoFile << "Número de cores de la máquina: " << numCores << endl;
    	infoFile << "-----------------------------------------" << endl;
    	infoFile.close();
*/
	return 0;

}

void
G4GROSimulator::Initialize(Event& theEvent, string cfgFile)
{

	cout << "[INFO] G4GROSimulator::Initialize" << endl;
	cout << "[INFO] G4GROSimulator::Initialize: Reading configuration file " << cfgFile << endl;

	// Fill Event object from configuration file
	// Read Simulation configuration
	theEvent = ConfigManager::ReadConfigurationFile(cfgFile);
	// get simulation simulation settings
	const Event::Config &cfg = theEvent.GetConfig();
	ConfigManager::PrintConfig(cfg);
	// Read Detector Configuration
	ConfigManager::ReadDetectorList(cfg.fDetectorList, theEvent);

}


bool
G4GROSimulator::RunSimulation(Event& theEvent)
{

	cout << "[INFO] G4GROSimulator::RunSimulation" << endl;

	SimData& simData = theEvent.GetSimData();
	const Event::Config &cfg = theEvent.GetConfig();
	const unsigned int numberOfParticles = simData.GetTotalNumberOfParticles();
	cout << "[INFO] G4GROSimulator::RunSimulation: Number of particles to be simulated = " << numberOfParticles << endl;

	if (!numberOfParticles) {
		cerr << "[ERROR] G4GROSimulator::RunSimulation: No Particles in the Event! ATMiting." << endl;
		return false;
	}

	/***************

		Geant4 Setup

	*****************/

	G4long myseed = time(NULL);
	G4Random::setTheEngine(new CLHEP::RanecuEngine);
	G4Random::setTheSeed(myseed);

	G4VisManager* fVisManager = nullptr;

	// construct the default run manager
	auto fRunManager =
		G4RunManagerFactory::CreateRunManager(G4RunManagerType::Serial);

	// set mandatory initialization classes
	auto fDetConstruction = new G4GROConstruction(theEvent);
	fRunManager->SetUserInitialization(fDetConstruction);

	fRunManager->SetUserInitialization(new G4MPhysicsList(fPhysicsName));

	G4MPrimaryGeneratorAction *fPrimaryGenerator = new G4MPrimaryGeneratorAction(theEvent);
	fRunManager->SetUserAction(fPrimaryGenerator);

	G4GROStackingAction *fStackingAction = new G4GROStackingAction(theEvent);
	fRunManager->SetUserAction(fStackingAction);

	G4GRORunAction *fRunAction = new G4GRORunAction();
	fRunManager->SetUserAction(fRunAction);

	G4GROEventAction *fEventAction = new G4GROEventAction();
	fRunManager->SetUserAction(fEventAction);

	fRunManager->SetUserAction(new G4GROTrackingAction());

	G4GROSteppingAction *fSteppingAction = new G4GROSteppingAction(fDetConstruction, fEventAction, theEvent);
	fRunManager->SetUserAction(fSteppingAction);

	// initialize G4 kernel
	fRunManager->Initialize();

	// initialize visualization
	if ((cfg.fGeoVis || cfg.fTrajVis) && !fVisManager)
		fVisManager = new G4VisExecutive;

	// get the pointer to the UI manager and set verbosities
	G4UImanager* fUImanager = G4UImanager::GetUIpointer();
	switch (fVerbosity) {
		case 1:
			fUImanager->ApplyCommand("/run/verbose 1");
			fUImanager->ApplyCommand("/event/verbose 0");
			fUImanager->ApplyCommand("/tracking/verbose 0");
			break;
		case 2:
			fUImanager->ApplyCommand("/run/verbose 1");
			fUImanager->ApplyCommand("/event/verbose 1");
			fUImanager->ApplyCommand("/tracking/verbose 0");
			break;
		case 3:
			fUImanager->ApplyCommand("/run/verbose 1");
			fUImanager->ApplyCommand("/event/verbose 1");
			fUImanager->ApplyCommand("/tracking/verbose 1");
			break;
		default:
			fUImanager->ApplyCommand("/run/verbose 0");
			fUImanager->ApplyCommand("/event/verbose 0");
			fUImanager->ApplyCommand("/tracking/verbose 0");
		}

	if (cfg.fGeoVis || cfg.fTrajVis) {
		fVisManager->Initialize();
		fUImanager->ApplyCommand(("/vis/open " + fRenderFile).c_str());
		fUImanager->ApplyCommand("/vis/scene/create");
		fUImanager->ApplyCommand("/vis/sceneHandler/attach");
		fUImanager->ApplyCommand("/vis/scene/add/volume");
		fUImanager->ApplyCommand("/vis/scene/add/axes 0 0 0 1 m");
		fUImanager->ApplyCommand("/vis/viewer/set/viewpointThetaPhi 0. 0.");
		fUImanager->ApplyCommand("/vis/viewer/set/targetPoint 0 0 0");
		fUImanager->ApplyCommand("/vis/viewer/zoom 1");
		fUImanager->ApplyCommand("/vis/viewero/set/style/wireframe");
		fUImanager->ApplyCommand("/vis/drawVolume");
		fUImanager->ApplyCommand("/vis/scene/notifyHandlers");
		fUImanager->ApplyCommand("/vis/viewer/update");

	}

	if (cfg.fTrajVis) {
			fUImanager->ApplyCommand("/tracking/storeTrajectory 1");
                        fUImanager->ApplyCommand("/vis/modeling/trajectories/create/drawByParticleID");
			fUImanager->ApplyCommand("/vis/scene/add/trajectories");
	}


	// loop over particle vector
	for (auto it = simData.GetParticleVector().begin(); it != simData.GetParticleVector().end(); ++it) {
		G4GROSimulator::currentParticle = *it;
		simData.SetCurrentParticle(*it);
		// Run simulation
		fRunManager->BeamOn(1);
	}


	delete fVisManager;
	delete fRunManager;

	cout << "[INFO] G4GROSimulator::RunSimulation: Geant4 Simulation ended successfully. " << endl;

	return true;

}


void
G4GROSimulator::WriteEventInfo(Event& theEvent)
{
	cout << "[INFO] G4GROSimulator::WriteEventInfo" << endl;


	DataWriter::FileWriter(theEvent);

	return;

}
