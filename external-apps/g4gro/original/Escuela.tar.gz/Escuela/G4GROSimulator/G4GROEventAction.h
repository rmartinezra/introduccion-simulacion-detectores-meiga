// definition of G4GROEventAction class
#ifndef G4GROEventAction_h
#define G4GROEventAction_h 1

#include "G4UserEventAction.hh"
#include "G4Event.hh"

#include "G4GRORunAction.h"

#include <string>
#include <vector>


class G4GROEventAction : public G4UserEventAction
{
  public:
    G4GROEventAction();
    virtual ~G4GROEventAction();

    virtual void BeginOfEventAction(const G4Event *event);
    virtual void EndOfEventAction(const G4Event *event);

};

#endif
