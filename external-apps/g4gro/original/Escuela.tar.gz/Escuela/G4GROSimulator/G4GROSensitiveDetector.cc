#include "G4GROSensitiveDetector.h"
#include "G4Track.hh"
#include "G4ParticleDefinition.hh"
#include "G4ThreeVector.hh"
#include "G4SystemOfUnits.hh"
#include <fstream>
#include <map>
#include <sstream>
#include <stdexcept>

#include <iomanip>
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

namespace CorsikaUtil {

inline int NucleusCode(unsigned int Z, unsigned int A)
{
  return 100 * A + Z;
}

} // namespace CorsikaUtil


/* ------------------------------------------------------------
   CORSIKA ↔ PDG conversion
   ------------------------------------------------------------ */
namespace Corsika {

namespace { // anonymous namespace (file-local)

std::map<int, int> gCorsikaToPDGMap;
std::map<int, int> gPDGToCorsikaMap;

void InsertCorsikaToPDG(int corsika, int pdg)
{
  gCorsikaToPDGMap[corsika] = pdg;
}

void InitCorsikaToPDGMap()
{
  InsertCorsikaToPDG(1,  22);     // gamma
  InsertCorsikaToPDG(2,  -11);    // e+
  InsertCorsikaToPDG(3,  11);     // e-
  InsertCorsikaToPDG(5,  -13);    // mu+
  InsertCorsikaToPDG(6,  13);     // mu-
  InsertCorsikaToPDG(7,  111);    // pi0
  InsertCorsikaToPDG(8,  211);    // pi+
  InsertCorsikaToPDG(9,  -211);   // pi-

  InsertCorsikaToPDG(10, 130);    // K0L
  InsertCorsikaToPDG(11, 321);    // K+
  InsertCorsikaToPDG(12, -321);   // K-
  InsertCorsikaToPDG(13, 2112);   // neutron
  InsertCorsikaToPDG(14, 2212);   // proton
  InsertCorsikaToPDG(15, -2212);  // anti-proton
  InsertCorsikaToPDG(16, 310);    // K0S

  InsertCorsikaToPDG(17, 221);    // eta
  InsertCorsikaToPDG(18, 3122);   // Lambda
  InsertCorsikaToPDG(19, 3222);   // Sigma+
  InsertCorsikaToPDG(20, 3212);   // Sigma0
  InsertCorsikaToPDG(21, 3112);   // Sigma-
  InsertCorsikaToPDG(22, 3322);   // Xi0
  InsertCorsikaToPDG(23, 3312);   // Xi-
  InsertCorsikaToPDG(24, 3334);   // Omega-

  InsertCorsikaToPDG(25, -2112);  // anti-neutron
  InsertCorsikaToPDG(26, -3122);  // anti-Lambda
  InsertCorsikaToPDG(27, -3222);  // anti-Sigma+
  InsertCorsikaToPDG(28, -3212);  // anti-Sigma0
  InsertCorsikaToPDG(29, -3112);  // anti-Sigma-
  InsertCorsikaToPDG(30, -3322);  // anti-Xi0
  InsertCorsikaToPDG(31, -3312);  // anti-Xi-
  InsertCorsikaToPDG(32, -3334);  // anti-Omega-

  InsertCorsikaToPDG(49, 333);    // phi

  InsertCorsikaToPDG(50, 223);    // omega
  InsertCorsikaToPDG(51, 113);    // rho0
  InsertCorsikaToPDG(52, 213);    // rho+
  InsertCorsikaToPDG(53, -213);   // rho-

  InsertCorsikaToPDG(54, 2224);   // Delta++
  InsertCorsikaToPDG(55, 2214);   // Delta+
  InsertCorsikaToPDG(56, 2114);   // Delta0
  InsertCorsikaToPDG(57, 1114);   // Delta-

  InsertCorsikaToPDG(58, -2224);  // anti-Delta--
  InsertCorsikaToPDG(59, -2214);  // anti-Delta-
  InsertCorsikaToPDG(60, -2114);  // anti-Delta0
  InsertCorsikaToPDG(61, -1114);  // anti-Delta+

  InsertCorsikaToPDG(62, 313);    // K*0
  InsertCorsikaToPDG(63, 323);    // K*+
  InsertCorsikaToPDG(64, -323);   // anti-K*-
  InsertCorsikaToPDG(65, -313);   // anti-K*0

  InsertCorsikaToPDG(66, 12);     // nu_e
  InsertCorsikaToPDG(67, -12);    // anti-nu_e
  InsertCorsikaToPDG(68, 14);     // nu_mu
  InsertCorsikaToPDG(69, -14);    // anti-nu_mu

  InsertCorsikaToPDG(71, 221);    // eta variants
  InsertCorsikaToPDG(72, 221);
  InsertCorsikaToPDG(73, 221);
  InsertCorsikaToPDG(74, 221);

  InsertCorsikaToPDG(95, -13);    // decayed mu+
  InsertCorsikaToPDG(96, 13);     // decayed mu-
}


void InitPDGToCorsikaMap()
{
  if (gCorsikaToPDGMap.empty())
    InitCorsikaToPDGMap();

  for (const auto& kv : gCorsikaToPDGMap)
    gPDGToCorsikaMap[kv.second] = kv.first;
}

} // anonymous namespace


int PDGToCorsika(int pdgCode)
{
  if (gPDGToCorsikaMap.empty())
    InitPDGToCorsikaMap();

  const auto it = gPDGToCorsikaMap.find(pdgCode);
  return (it != gPDGToCorsikaMap.end()) ? it->second : 0;
}

} // namespace Corsika

/* ============================================================
   G4ATMSensitiveDetector
   ============================================================ */

////////////////////////////////////////////////////////////////////////////////////////////////////////////////


G4GROSensitiveDetector::G4GROSensitiveDetector(const G4String& name, Event& event)
    : G4VSensitiveDetector(name), fEvent(event)
{
    G4cout << "[G4GROSensitiveDetector] Sensitive detector created: " << name << G4endl;
}

G4GROSensitiveDetector::~G4GROSensitiveDetector() {}

G4bool G4GROSensitiveDetector::ProcessHits(G4Step* step, G4TouchableHistory*)
{
    G4Track* track = step->GetTrack();
    //G4String particleName = track->GetDefinition()->GetParticleName();

    const G4ParticleDefinition* pdef = track->GetDefinition();
  const G4int pdg = pdef->GetPDGEncoding();

  int corsika_code = 0;

  if (pdef->GetParticleType() == "nucleus") {
  corsika_code = CorsikaUtil::NucleusCode(
      pdef->GetAtomicNumber(),
      pdef->GetAtomicMass()
  );
} else {
  corsika_code = Corsika::PDGToCorsika(pdg);
}

    bool esNeutrino = (corsika_code >= 66 && corsika_code <= 69);

    if (!esNeutrino)   // solo entra si NO es neutrino
    {

    G4ThreeVector pos = step->GetPreStepPoint()->GetPosition();
    G4ThreeVector mom = track->GetMomentum();

    double shower_id = 0;
    double prm_id = 0;
    double prm_energy = 0;
    double prm_theta = 0;
    double prm_phi = 0;
    //std::string particle = particleName;

    // Archivo con nombre fijo
    std::ofstream outfile("soild_campanas_10H.shw", std::ios_base::app);


    //outfile << particle << " "
    std::ostringstream os;
    os << std::setw(4) << std::setfill('0') << corsika_code;

    outfile << os.str() << " "
            << mom.x() / GeV << " " << mom.y() / GeV << " " << -mom.z() / GeV << " "
            << pos.x() << " " << pos.y() << " " << pos.z() << " "
            << shower_id << " " << prm_id << " " << prm_energy << " "
            << prm_theta << " " << prm_phi << std::endl;

    outfile.close();
    }
    //track->SetTrackStatus(fStopAndKill);
    return true;
}
