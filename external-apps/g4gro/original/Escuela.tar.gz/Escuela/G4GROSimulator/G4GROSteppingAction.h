// definition of the G4GROSteppingAction class

#ifndef G4GROSteppingAction_h
#define G4GROSteppingAction_h 1
#include <iostream>
#include "G4UserSteppingAction.hh"
#include "G4String.hh"

#include "Event.h"


class G4GROConstruction;
class G4GROEventAction;

/* Stepping action class.
     UserSteppingAction collects info at a step level
*/

class G4GROSteppingAction : public G4UserSteppingAction
{
    public:
        G4GROSteppingAction(const G4GROConstruction* det, G4GROEventAction* event, Event& theEvent);
        virtual ~G4GROSteppingAction();
        virtual void UserSteppingAction(const G4Step* step);

    private:
        const G4GROConstruction* fDetectorConstruction;
        G4GROEventAction* fEventAction;
        std::ofstream* fOutputFile;
        Event& fEvent;

        G4double fSiPMTime;
        G4double fScinTime;
        G4String stepVolume;
        G4String trackVolume;
      
};

#endif
