// implementation of the G4GRORunAction class

#include "G4Timer.hh"
#include "G4Run.hh"
#include "g4root.hh"
#include "G4AccumulableManager.hh"

#include "G4GRORunAction.h"
//#include "histosRun.hh"

//#include <TFile.h>

G4GRORunAction::G4GRORunAction()
 : G4UserRunAction()
{
  G4cout << "...G4GRORunAction..." << G4endl;
}


G4GRORunAction::~G4GRORunAction()
{}


void
G4GRORunAction::BeginOfRunAction(const G4Run* )
{

}


void
G4GRORunAction::EndOfRunAction(const G4Run* )
{

}
