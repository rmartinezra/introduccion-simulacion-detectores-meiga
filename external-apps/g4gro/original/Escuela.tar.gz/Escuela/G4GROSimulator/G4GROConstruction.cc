// Implementation of the G4GROConstruction class
#include <iostream>

#include "G4GROConstruction.h"
#include "Materials.h"
#include "G4SDManager.hh"
#include "G4UnitsTable.hh"

//Libraries
#include "G4VUserDetectorConstruction.hh"
#include "G4VPhysicalVolume.hh"
#include "G4LogicalVolume.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4PVPlacement.hh"
#include "G4NistManager.hh"
#include "G4SystemOfUnits.hh"
#include "G4GenericMessenger.hh"
#include "G4OpticalSurface.hh"
#include "G4LogicalBorderSurface.hh"
#include "G4LogicalSkinSurface.hh"

#include "G4SystemOfUnits.hh"
#include "G4PhysicalConstants.hh"

#include "G4GROSensitiveDetector.h"
#include "G4SDManager.hh"

#include <G4VisAttributes.hh>
#include <G4Colour.hh>
#include "Event.h"
#include "Detector.h"
#include "ConfigManager.h"

// Incluir la librería de mapas
#include <map>
#include <stdexcept>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/xml_parser.hpp>

using namespace CLHEP;
using namespace std;

G4GROConstruction::G4GROConstruction(Event& theEvent) :
	G4VUserDetectorConstruction(),
	fEvent(theEvent)
{
//G4cout << "*********************************************"<< endl;
//G4cout << "...G4GROConstruction..." << endl;
	fCheckOverlaps = fEvent.GetConfig().fCheckOverlaps;
/*	G4cout << "*********************************************"<< endl;
        using boost::property_tree::ptree;
        Event::Config &cfg = fEvent.GetConfig();
				string aDetectorList = fEvent.GetConfig().fDetectorList;
				ptree tree;
				read_xml(aDetectorList, tree);
				NLayers = tree.get<int>("detectorList.detector.NLayers", 1);
				cout << "[DEBUG] G4ExDetectorConstruction::CreateWorld: NLayers = " << NLayers << endl;
				std::cout << " Numbers of layers "<< NLayers << endl;*/
}

G4GROConstruction::~G4GROConstruction()
	{
	}


G4VPhysicalVolume*
G4GROConstruction::CreateDetector()
{
	CreateWorld();
	CreateGround();
	CreateSens();
	PlaceDetector(fEvent);
	return physWorld;
}


// --------------------------------------------------------------------
// Mother Volume
// --------------------------------------------------------------------
void G4GROConstruction::CreateWorld()
{
    // Create a mother volume
    		solidWorld = new G4Box("World", fWorldSizeX/2, fWorldSizeY/2, fWorldSizeZ/2);
    		logicWorld = new G4LogicalVolume(solidWorld, Materials().Air, "World");
    		physWorld = new G4PVPlacement(nullptr, G4ThreeVector(0,0,0), "World", logicWorld, 0, false, 0, fCheckOverlaps);
    		G4cout << "*********************************************"<< endl;
    		G4cout << "...G4GROConstruction : CREATE WORLD" << endl;
    		G4cout << " fWorldSizeX "<< fWorldSizeX/m <<" in m"<< endl;
    		G4cout << " fWorldSizeY "<< fWorldSizeY/m <<" in m"<< endl;
    		G4cout << " fWorldSizeZ "<< fWorldSizeZ/m <<" in m"<< endl;
    		G4cout << "*********************************************"<< endl;
}


void G4GROConstruction::CreateUniver()
{
    // Create a universe volume
    solidUniver = new G4Box("Univer", fUniverSizeX/2, fUniverSizeY/2, fUniverSizeZ/2);
    logicUniver = new G4LogicalVolume(solidUniver, Materials().Air, "Univer");
    physUniver = new G4PVPlacement(nullptr, G4ThreeVector(0,0,0), "Univer", logicUniver, nullptr, false, 0, fCheckOverlaps);
    
    G4cout << "*********************************************" << endl;
    G4cout << "...G4GROConstruction : CREATE UNIVER" << endl;
    G4cout << " fUniverSizeX " << fUniverSizeX/CLHEP::m << " in m" << endl;
    G4cout << " fUniverSizeY " << fUniverSizeY/CLHEP::m << " in m" << endl;
    G4cout << " fUniverSizeZ " << fUniverSizeZ/CLHEP::m << " in m" << endl;
    G4cout << "*********************************************" << endl;
}


// --------------------------------------------------------------------
// Layer to measure neutrons (Air_vacuum)
// --------------------------------------------------------------------
void G4GROConstruction::CreateSens()
{

    solidSens1 = new G4Box("Layer_Detectoruno", fSens1SizeX/2, fSens1SizeY/2, fSens1SizeZ/2);
    logicSens1 = new G4LogicalVolume(solidSens1, Materials().Air, "Detectoruno");
    G4double z_sens = -97.2*m;
    physSens1 = new G4PVPlacement(nullptr, G4ThreeVector(0, 0, z_sens), logicSens1, "Detectoruno", logicWorld, false, 0, true);

    G4VisAttributes magenta(G4Colour::Magenta());
    logicSens1->SetVisAttributes(magenta);

    // Asociar el sensitive detector
    G4SDManager* sdManager = G4SDManager::GetSDMpointer();
    auto groSD = new G4GROSensitiveDetector("GRO_SD", fEvent);
    sdManager->AddNewDetector(groSD);
    logicSens1->SetSensitiveDetector(groSD);

    G4cout << "*********************************************"<< endl;
    G4cout << "...G4GROConstruction : Detector Layer built!" << endl;
    G4cout << " Detector center Z = " << z_sens / m << " m" << endl;
    G4cout << "*********************************************"<< endl;

    // Para el detector
    G4cout << "Detector center Z = " << z_sens/m << " m" << G4endl;
    G4cout << "Detector extends from Z = " 
       << (z_sens - fSens1SizeZ/2.0)/m << " m to " 
       << (z_sens + fSens1SizeZ/2.0)/m << " m" << G4endl;
}



//------------------------------------------------------------------------
//Soil's Model
//------------------------------------------------------------------------
void G4GROConstruction::CreateGround()
{
    solidGround = new G4Box("Layer_Ground", fGroundSizeX / 2, fGroundSizeY / 2, fGroundSizeZ / 2);
    logicGround = new G4LogicalVolume(solidGround, Materials().SoilBS, "Ground"); //Select the soil : SoilBH5, 25, StdRock
    physGround = new G4PVPlacement(nullptr, G4ThreeVector(0, 0, -98.5*m), logicGround, "Ground", logicWorld, false, 0, fCheckOverlaps);
    G4VisAttributes brown(G4Colour::Brown());
    logicGround->SetVisAttributes(brown);
    G4cout << "*********************************************"<< endl;
    G4cout << "...G4GROUNDConstruction : CREATE GROUND" << endl;
    G4cout << " Atmosphere center location :  (0 , 0, 0)"<< " in m"<< endl;
    G4cout << "*********************************************"<< endl;


    // Para el suelo
    G4cout << "Ground center Z = " << 0/m << " m" << G4endl;
    G4cout << "Ground extends from Z = " << -fGroundSizeZ/2.0/m;
    G4cout  << " m to " << +fGroundSizeZ/2.0/m << " m" << G4endl;
}

//---------------------------------------------------------------------------------------------------
void
G4GROConstruction::PlaceDetector(Event& theEvent)
{
	// loop in detector vector
	for (auto detIt = theEvent.DetectorRange().begin(); detIt != theEvent.DetectorRange().end(); detIt++) {
		auto& currentDet = detIt->second;
		BuildDetector(logicWorld, currentDet, theEvent, fCheckOverlaps);
	}

}

G4VPhysicalVolume*
G4GROConstruction::Construct()
{
	if (!physWorld) {
		return CreateDetector();
	}
	return physWorld;
}
