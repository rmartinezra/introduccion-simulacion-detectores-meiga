// definition of the G4GROConstruction class
#ifndef G4GROConstruction_h
#define G4GROConstruction_h 1

#include "G4VUserDetectorConstruction.hh"
#include "G4SDManager.hh"
#include "globals.hh"
#include "G4Element.hh"
#include "G4ElementTable.hh"
#include "G4Material.hh"
#include "G4MaterialTable.hh"
#include "G4PVPlacement.hh"
#include "G4LogicalVolume.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4SystemOfUnits.hh"
#include "G4LogicalSkinSurface.hh"
#include "G4OpticalSurface.hh"
#include "G4VisAttributes.hh"
#include "G4Colour.hh"

#include "CLHEP/Units/PhysicalConstants.h" // For physical constants like CLHEP::Avogadro number

#include "Event.h"
#include "Detector.h"

class G4VPhysicalVolume;
class G4LogicalVolume;
class G4OpticalSkinSurface;

// Detector construction class to define materials and geometry

class G4GROConstruction : public G4VUserDetectorConstruction {

	public:
		G4GROConstruction(Event& theEvent);
		virtual ~G4GROConstruction();
		virtual G4VPhysicalVolume* Construct();

	private:

		void CreateWorld();
		void CreateUniver();
		void CreateSens();
                void CreateGround();

		void PlaceDetector(Event& theEvent);
		G4VPhysicalVolume* CreateDetector();

		bool fCheckOverlaps = false;

		// solids
		G4Box* solidWorld = nullptr;
		G4Box* solidUniver = nullptr;
		G4Box* solidSens1 = nullptr;
		G4Box* solidSens2 = nullptr;
		G4Box* solidGround = nullptr;

		// logical and physical volumes
		G4LogicalVolume* logicWorld = nullptr;
		G4PVPlacement*   physWorld  = nullptr;
		G4LogicalVolume* logicUniver = nullptr;
		G4PVPlacement*   physUniver  = nullptr;
		G4LogicalVolume* logicSens1 = nullptr;
		G4PVPlacement*   physSens1  = nullptr;
		//G4LogicalVolume* logicSens2 = nullptr;
		//G4PVPlacement*   physSens2  = nullptr;
		G4LogicalVolume* logicGround = nullptr;
		G4PVPlacement*   physGround  = nullptr;

		// size definitions
		G4double fWorldSizeX = 4 *CLHEP::m;
		G4double fWorldSizeY = 40 *CLHEP::m;
		G4double fWorldSizeZ = 200 *CLHEP::m;

		G4double fUniverSizeX = 40.1 *CLHEP::m;
		G4double fUniverSizeY = 40.1 *CLHEP::m;
		G4double fUniverSizeZ = 200 *CLHEP::m;
	
		G4double fSens1SizeX = 40 *CLHEP::m;
		G4double fSens1SizeY = 40 *CLHEP::m;
		G4double fSens1SizeZ = 0.01 *CLHEP::m;

		G4double fGroundSizeX = 40 *CLHEP::m;
		G4double fGroundSizeY = 40 *CLHEP::m;
		G4double fGroundSizeZ = 1 *CLHEP::m;

		G4int NLayers = 1;

		Event& fEvent;

};


#endif
