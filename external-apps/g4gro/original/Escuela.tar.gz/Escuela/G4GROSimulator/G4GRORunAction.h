// definition of the G4GRORunAction class

#ifndef G4GRORunAction_h
#define G4GRORunAction_h 1

#include "globals.hh"
#include "G4UserRunAction.hh"
#include "g4root.hh"

#include <fstream>
#include <iostream>
#include <string>


class G4Run;


class G4GRORunAction : public G4UserRunAction
{
  public:
    G4GRORunAction();
    virtual ~G4GRORunAction();

    virtual void BeginOfRunAction(const G4Run* aRun);
    virtual void EndOfRunAction(const G4Run* aRun);

    std::ofstream* outFile;


  private:
};
#endif
