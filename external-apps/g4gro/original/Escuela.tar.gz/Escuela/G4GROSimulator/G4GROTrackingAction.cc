#include "G4GROTrackingAction.h"
#include "G4GROSimulator.h"

#include <G4Track.hh>
#include <G4TrackingManager.hh>
#include <G4TrackStatus.hh>

#include "Particle.h"


void
G4GROTrackingAction::PreUserTrackingAction(const G4Track* track)
{

}


void
G4GROTrackingAction::PostUserTrackingAction(const G4Track* track)
{

}
