// implementation of the G4GROEventAction class

#include "G4GROEventAction.h"

#include "G4Track.hh"

G4GROEventAction::G4GROEventAction() : G4UserEventAction()
{
  G4cout << "...G4GROEventAction..." << G4endl;

}

G4GROEventAction::~G4GROEventAction()
{

}

void
G4GROEventAction::BeginOfEventAction(const G4Event*)
{

}

void
G4GROEventAction::EndOfEventAction(const G4Event* )
{

}
