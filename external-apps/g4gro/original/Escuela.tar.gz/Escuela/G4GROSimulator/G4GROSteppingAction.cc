// implementation of the G4GROSteppingAction class
#include "G4GROSimulator.h"
#include "G4GROSteppingAction.h"
#include "G4GROConstruction.h"
#include "G4GROEventAction.h"
#include "G4GROTrackingAction.h"
#include "G4GROStackingAction.h"

#include "G4Step.hh"
#include "G4Track.hh"
#include "G4RunManager.hh"
#include "G4UserEventAction.hh"
#include "G4Event.hh"
#include "G4ThreeVector.hh"
#include "G4ParticleDefinition.hh"
#include "G4Track.hh"
#include "G4SystemOfUnits.hh"

#include "G4GRORunAction.h"


#include <string>
#include <vector>

#include "G4OpticalPhoton.hh"

#include "SimData.h"
#include "Detector.h"

#include <fstream>
#include <vector>
#include <string>
#include <zlib.h>
#include <nlohmann/json.hpp>

#include "G4TransportationManager.hh"
#include "G4Navigator.hh"
#include <fstream>
#include <nlohmann/json.hpp>


using namespace std;

// Add this class definition
class MyTrackInfo : public G4VUserTrackInformation {
public:
    MyTrackInfo(G4int id) : myID(id) {}
    virtual ~MyTrackInfo() {}

    void SetMyID(G4int id) { myID = id; }
    G4int GetMyID() const { return myID; }

private:
    G4int myID;
};


G4GROSteppingAction::G4GROSteppingAction(const G4GROConstruction* det, G4GROEventAction* G4event, Event& theEvent)
	: G4UserSteppingAction(),
		fDetectorConstruction(det),
		fEventAction(G4event),
    fEvent(theEvent)
{
	    // Get filename from Event
    Event::Config &cfg = fEvent.GetConfig();
    std::string outputFileName = cfg.fOutputFileName;

    // Create the output file
    fOutputFile = new std::ofstream(outputFileName + "_neutrons.shw", std::ios_base::app);

    // Optional: header
    if (fOutputFile && fOutputFile->tellp() == 0) {
        *fOutputFile << "# particle px[MeV/c] py[MeV/c] pz[MeV/c] x_pre[m] y_pre[m] z_pre[m] preProcess x_pos[m] y_pos[m] z_pos[m] postProcess E[MeV] trackID parentID myID\n";
    }

}

G4GROSteppingAction::~G4GROSteppingAction()

{
	if (fOutputFile) {
        if (fOutputFile->is_open()) {
            fOutputFile->close();
        }
        delete fOutputFile;
        fOutputFile = nullptr;
    }

}

void G4GROSteppingAction::UserSteppingAction(const G4Step* step) {

   if (!step) return;

    G4Track* track = step->GetTrack();
    if (!track) return;
    
    // Seguridad: obtener puntos pre/post y comprobar
    G4StepPoint* postPoint = step->GetPostStepPoint();
    G4StepPoint* prePoint  = step->GetPreStepPoint();
    if (!postPoint || !prePoint) return;
    
    G4String particleName = track->GetDefinition() ? track->GetDefinition()->GetParticleName() : "unknown";
      
    G4ThreeVector pos = postPoint->GetPosition();
    G4ThreeVector pre = prePoint->GetPosition();
       
    G4ThreeVector mom = track->GetMomentum();
    G4double E = track->GetKineticEnergy() / MeV;
    
    // === LÍMITES DE LA ATMÓSFERA ===
    const G4double limitX = 20.0 * m;
    const G4double limitY = 20.0 * m;
    const G4double limitZ = 100.0 * m;
      
    G4bool hitX = std::abs(pos.x()) >= limitX;
    G4bool hitY = std::abs(pos.y()) >= limitY;
    G4bool hitZ = std::abs(pos.z()) >= limitZ;
      
    //G4bool exitingX = hitX && (pos.x() * mom.x() > 0);
    //G4bool exitingY = hitY && (pos.y() * mom.y() > 0);i
    
    G4bool exitingX = std::abs(pos.x()) >= limitX;
    G4bool exitingY = std::abs(pos.y()) >= limitY;
      
    // Asegurarnos de tener user info, si no crear una mínima
    MyTrackInfo* info = dynamic_cast<MyTrackInfo*>(track->GetUserInformation());
    if (!info) {
        // Si no hay info, crear y asociar para evitar nullptrs más adelante
        info = new MyTrackInfo(track->GetTrackID());
        track->SetUserInformation(info);
    } 
      
    // Guardamos el myID si nos interesa escribirlo
    G4int myID = info ? info->GetMyID() : -1;
      
    // Solo trabajar con primarios (según tu lógica original)
    //if (track->GetParentID() == 0) {
    /*if (particleName == "neutron") {
    //if (particleName == "mu+" || particleName == "mu-") {
        // PRE-PROCESS (seguro: comprobar puntero a proceso)
        G4String preProcess = "Start";
        if (prePoint->GetProcessDefinedStep() != nullptr) {
            preProcess = prePoint->GetProcessDefinedStep()->GetProcessName();
        }
      
        // POST-PROCESS (seguro)
        G4String postProcess = "Transportation";
        if (postPoint->GetProcessDefinedStep() != nullptr) {
                postProcess = postPoint->GetProcessDefinedStep()->GetProcessName();
        } else {
                postProcess = "Transportation";
        }
      
        // Escribir línea en fichero (si está abierto)
        if (fOutputFile && fOutputFile->is_open()) {
            (*fOutputFile) << "PRIMARIA_TRACKING "
                           << particleName << " "
                           << mom.x()/MeV << " " << mom.y()/MeV << " " << mom.z()/MeV << " "
                           << pre.x()/m << " " << pre.y()/m << " " << pre.z()/m << " "
                           << preProcess << " "
                           << pos.x()/m << " " << pos.y()/m << " " << pos.z()/m << " "
                           << postProcess << " "
                           << E << " "
                           << track->GetTrackID() << " "
                           << track->GetParentID() << " "
                           << myID << G4endl;
        }
    }*/     

    // -------------------------------------------------------



    if ((exitingX || exitingY) && !hitZ) {
        // Corrección de posición: colocar la partícula ligeramente dentro del límite
        G4ThreeVector correctedPos = pos;
	
	// Periodicidad en X
        if (correctedPos.x() > limitX)  correctedPos.setX(correctedPos.x() - 2.0 * limitX - 10.0*cm );
	if (correctedPos.x() < -limitX)  correctedPos.setX(correctedPos.x() + 2.0 * limitX + 10.0*cm );
	// Periodicidad en Y
	if (correctedPos.y() > limitY)  correctedPos.setY(correctedPos.y() - 2.0 * limitY - 10.0*cm );
	if (correctedPos.y() < -limitY)  correctedPos.setY(correctedPos.y() + 2.0 * limitY + 10.0*cm );
        
	//postPoint->SetPosition(correctedPos);
        track->SetPosition(correctedPos);
	// Reubicar el navigator
        G4TransportationManager::GetTransportationManager()
            ->GetNavigatorForTracking()
            ->LocateGlobalPointAndSetup(correctedPos);
    }


}
