#ifndef G4GROSensitiveDetector_h
#define G4GROSensitiveDetector_h 1

#include "G4VSensitiveDetector.hh"
#include "globals.hh"
#include "Event.h"

class G4Step;
class G4TouchableHistory;

class G4GROSensitiveDetector : public G4VSensitiveDetector {
public:
    G4GROSensitiveDetector(const G4String& name, Event& event);
    virtual ~G4GROSensitiveDetector();

    virtual G4bool ProcessHits(G4Step* step, G4TouchableHistory* history) override;

private:
    Event& fEvent;
};

#endif

