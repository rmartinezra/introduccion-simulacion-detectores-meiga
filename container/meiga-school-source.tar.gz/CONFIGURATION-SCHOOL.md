# Configuración autocontenida de MEIGA School

Todas las rutas de los JSON se resuelven respecto al propio archivo JSON. Se puede ejecutar una aplicación desde cualquier directorio con `./Aplicacion -c /ruta/config.json`.

## Opciones JSON admitidas

- `Input.Mode`: `UseEcoMug` o `UseARTI`.
- `Input.InputNParticles`: entero usado por `UseEcoMug`.
- `Input.InputFileName`: archivo local usado por `UseARTI`.
- `DetectorList`: ruta al XML de detectores.
- `DetectorProperties`: ruta al XML de propiedades predeterminadas.
- `Output.OutputFile`, `CompressOutput`, `SaveInput`, `SavePETimeDistribution`, `SaveComponentsPETimeDistribution`, `SaveTraces`, `SaveEnergy`, `SaveComponentsEnergy`, `SaveCharge`, `SaveCounts`.
- `Simulation.SimulationMode`: `eFast` o `eFull`.
- `Simulation.GeoVisOn`, `TrajVisOn`, `CheckOverlaps`, `RenderFile`, `PhysicsName`, `Verbosity`.

## Opciones XML admitidas

`injectionMode.type` acepta `eCircle`, `eHalfSphere`, `eVertical` o `eFromFile`. Sus campos son `x`, `y`, `z`, `radius`, `height`, `minTheta`, `maxTheta`, `minPhi` y `maxPhi`.

Cada `detector` requiere `id`, `type`, `x`, `y` y `z`. Los tipos reconocidos por MEIGA son `eWCD`, `eScintillator`, `eMusaic`, `eMudulus`, `eHodoscope`, `eSaltyWCD` y `eDummy`.

Cada aplicación muestra únicamente las propiedades que utiliza su geometría:

- Hodoscopio y Torre: `numberOfBars`, `barLength`, `barWidth`, `barThickness`, `coatingThickness`, `rotationAngle`, `fiberRadius` y `claddingThickness`.
- WCD: `tankRadius`, `tankHeight` y `tankThickness`.

`DetectorProperties.xml` define los valores comunes de la aplicación. Un valor incluido dentro de un elemento `detector` en `DetectorList.xml` sobrescribe el valor común solo para ese detector. Los parámetros internos que la geometría actual no usa se omiten deliberadamente para evitar configuraciones engañosas.

## Uso rápido

Ejecute el binario sin argumentos para cargar automáticamente el JSON que está a su lado, o seleccione otro archivo con `-c`/`--config`. Use `--help` para mostrar la ayuda.

## Compilación

Ejecute `make` en la carpeta de la aplicación. El código editable está en `source/Applications/<Aplicacion>` y el ejecutable actualizado se copia a la raíz de la carpeta. Use `make clean` para descartar la compilación local y `make run` para compilar y ejecutar la configuración principal.
