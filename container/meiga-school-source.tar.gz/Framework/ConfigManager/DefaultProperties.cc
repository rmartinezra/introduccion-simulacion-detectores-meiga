#include "DefaultProperties.h"
#include "ConfigManager.h"


const ptree& empty_ptree(){
	static ptree t;
	return t;
}


void
DefaultProperties::SetDefaultProperties(const std::string& filename)
{

	if (filename.empty()) 
		return;
	std::cout << "[INFO] DefaultProperties::SetDefaultProperties: Setting default properties from file " << filename << std::endl;
	// read xml and set parameters
	ptree tree;
	read_xml(filename, tree);
	string branchName = "detectorProperties";
	// setting default detector properties from XML
	gTankRadius = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "tankRadius", 105.0, true, "cm");
	gTankHeight = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "tankHeight", 90.0, true, "cm");
	gTankThickness = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "tankThickness", 15.0, true, "mm");
	gImpuritiesFraction = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "impuritiesFraction", 0.0, false);
	
	gNumberOfBars = ConfigManager::GetPropertyFromXML<int>(tree, branchName, "numberOfBars", 15, false);
	gNumberOfPanels = ConfigManager::GetPropertyFromXML<int>(tree, branchName, "numberOfPanels", 1, false);
	gBarWidth = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "barWidth", 40.0, true, "mm");
	gBarLength = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "barLength", 600.0, true, "mm");
	gBarThickness = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "barThickness", 10.0, true, "mm");
	gCoatingThickness = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "coatingThickness", 0.25, true, "mm");
	gCasingThickness = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "casingThickness", 2.0, true, "mm");
	gRotationAngle = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "rotationAngle", 0.0, false);
	gFiberLength = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "fiberLength", 500.0, true, "mm");
	gFiberRadius = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "fiberRadius", 1.2, true, "mm");
	gCladdingThickness = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "claddingThickness", 0.10, true, "mm");
	
	gLength = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "length", 1000.0, true, "mm");
	gWidth = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "width", 1000.0, true, "mm");
	gThickness = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "thickness", 1000.0, true, "mm");
	gDistancePanels = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "distancePanels", 1000.0, true, "mm");
	
	// ground size parameters
	gGroundSizeX = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "groundSizeX", 5.0, true, "m");
	gGroundSizeY = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "groundSizeY", 5.0, true, "m");
	gGroundSizeZ = ConfigManager::GetPropertyFromXML<double>(tree, branchName, "groundSizeZ", 1.0, true, "m");

}
